export custom_compile_option="-O2"
debug_flag=""
mssanitizer_flag=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --debug)
            debug_flag="-DENABLE_DEBUG=ON"
            shift
            ;;
        --mssanitizer)
            mssanitizer_flag="-DENABLE_MS_SANITIZER=ON"
            shift
            ;;
        --simulator)
            simulator_flag="-DENABLE_SIMULATOR=ON -DASCEND_HOME_PATH=${ASCEND_HOME_PATH}"
            shift
            ;;
        *)
            shift
            ;;
    esac
done

# 设置 CMAKE_PREFIX_PATH
export CMAKE_PREFIX_PATH=${ASCEND_TOOLKIT_HOME}/compiler/tikcpp/ascendc_kernel_cmake:$CMAKE_PREFIX_PATH
# 创建并进入构建目录
rm -rf ./build
mkdir -p build
cd build
# 配置和编译
cmake .. ${debug_flag} ${mssanitizer_flag} ${simulator_flag}
make -j VERBOSE=1