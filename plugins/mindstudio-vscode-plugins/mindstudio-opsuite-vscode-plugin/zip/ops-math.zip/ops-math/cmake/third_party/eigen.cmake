# ----------------------------------------------------------------------------
# Copyright (c) 2025 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# ----------------------------------------------------------------------------
if(POLICY CMP0135)
    cmake_policy(SET CMP0135 NEW)
endif()
set(EIGEN_VERSION_PKG eigen-3.4.0.tar.gz)
if(IS_DIRECTORY "${CANN_3RD_LIB_PATH}/eigen")	
  set(REQ_URL "${CANN_3RD_LIB_PATH}/eigen")
else()
  set(REQ_URL "https://gitcode.com/cann-src-third-party/eigen/releases/download/3.4.0/${EIGEN_VERSION_PKG}")
endif()

set(EIGEN_DOWNLOAD_PATH ${CANN_3RD_LIB_PATH}/pkg)

include(ExternalProject)
ExternalProject_Add(external_eigen_math
  URL               ${REQ_URL}
  DOWNLOAD_DIR      ${EIGEN_DOWNLOAD_PATH}
  DOWNLOAD_NO_EXTRACT 0   #自动解压
  PREFIX            third_party
  CONFIGURE_COMMAND ""
  BUILD_COMMAND     ""
  INSTALL_COMMAND   ""
)

ExternalProject_Get_Property(external_eigen_math SOURCE_DIR)

add_library(EigenMath INTERFACE)
target_compile_options(EigenMath INTERFACE -w)

set_target_properties(EigenMath PROPERTIES
  INTERFACE_INCLUDE_DIRECTORIES "${SOURCE_DIR}"
)
add_dependencies(EigenMath external_eigen_math)

add_library(Eigen3::EigenMath ALIAS EigenMath)
