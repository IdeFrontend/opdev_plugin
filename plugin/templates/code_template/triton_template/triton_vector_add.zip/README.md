# Triton operator scaffold

Minimal template: one Python entry file plus this README (same layout idea as the `pyasc_temple` template).

## Contents

- `triton_vector_add.py` — small `@triton.jit` vector-add example using `torch` tensors on CPU. When you create a project with a custom name, the plugin renames this file and rewrites placeholder strings.

## Run

From the operator project directory:

```bash
python3 ./<your_operator>.py
```

Install Triton (and PyTorch) for your environment before running.

## Plugin actions

Build / run / debug use `python3 ./<operator>.py` in generated configs. Sanitizer, simulation, and on-board flows still expect a toolchain-specific setup—adjust generated scripts or config after you add real profiling wrappers.
