# 算子名称：hello_world
这是一个以addn为模板的样例代码，请开发者基于实际需求场景修改此算子代码，并及时提交，以防代码丢失。

## 快速开始

如何快速编译算子
| 模式 | 命令 | 用途 |
|------|------|------|
| 普通编译 | `bash build.sh` | 日常开发验证 |
| 异常检测 | `bash build.sh --mssanitizer` | 问题检测 |
| 上板调优 | `bash build.sh --onboard` | 真实环境性能分析 |
| 仿真调优 | `bash build.sh --simulator` | 指令级详细分析 |

## 指导视频
基于一站式算子开发平台快速完成算子创建、开发、异常检测、性能调优 
**[https://gitcode.com/opdevtools/introductiointroductionn/blob/main/opDevTools_intro.mp4](https://gitcode.com/opdevtools/introductiointroductionn/blob/main/opDevTools_intro.mp4)**